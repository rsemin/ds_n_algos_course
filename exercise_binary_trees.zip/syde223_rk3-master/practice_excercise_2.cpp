/*
 * Kha Nguyen - 20782252
 * Roman Semin - 20782237
 */
// C program to demonstrate insert operation in binary search tree.
#include <iostream>
#include <string>

#define ASSERT_TRUE(T) if (!(T)) return false;
#define ASSERT_FALSE(T) if ((T)) return false;

using namespace std;

struct BinaryTreeNode {
    int value;
    BinaryTreeNode *left, *right;
    BinaryTreeNode(int new_val) : value(new_val), left(NULL), right(NULL) {}
};

void find_and_print_sum_of_nodes (BinaryTreeNode* T, int desired_sum, int cur_sum, string buffer) {
    // exit if T is NULL
    if (!T) return;

    // update the ongoing sum with the current value for T
    int new_sum = cur_sum + T->value;

    // update the current path string
    string new_buffer = buffer + " " + to_string(T->value);

    // if the desired sum is found, print the corresponding path
    if (new_sum == desired_sum)
        cout << new_buffer << endl;

    // TODO: continue down the left subtree
    find_and_print_sum_of_nodes(T->left, desired_sum, new_sum, new_buffer);

    // TODO: continue down the right subtree
    find_and_print_sum_of_nodes(T->right, desired_sum, new_sum, new_buffer);

    // TODO: restart from the left subtree if buffer = “”
    if((T->left)&& (new_buffer == " " + to_string(T->value))){
        find_and_print_sum_of_nodes(T->left, desired_sum, 0, buffer);
    }

    // TODO: restart from the right subtree if buffer = “”
    if((T->right) && (new_buffer == " " + to_string(T->value))){
        find_and_print_sum_of_nodes(T->right, desired_sum, 0, buffer);
    }

// Driver Program to test above functions
}

int find_max_sum_of_nodes(BinaryTreeNode* T, int &temp_max_sum){
    // exit if T is NULL
    if (!T) return 0;

    // derive the maximum sum for the left subtree
    int left_sum = find_max_sum_of_nodes(T->left, temp_max_sum);

    // derive the maximum sum for the right subtree
    int right_sum= find_max_sum_of_nodes(T->right, temp_max_sum);

    // TODO: compare T->value, left_sum + T->value, and right_sum + T->value; store as max1
    int max1 = max(max(left_sum + T->value, right_sum + T->value), T->value);

    // TODO: compare max1, left_sum + right_sum + T->value; store as max2
    int max2 = max(max1, (left_sum + right_sum + T->value));

    // TODO: update temp_max_sum with the new max
    temp_max_sum = max(max(max1, max2), temp_max_sum);
    // TODO: return max1
    return max1; // because it's a single path. Returning max2 as temp_max_sum will give a cyclical path type of thing
                 // see example 1 on step 2 on why the max sum is 31 and not 36
}

int find_max_sum_of_nodes(BinaryTreeNode* T){
    int temp_max_sum = INT64_MIN;
    int max_test = find_max_sum_of_nodes(T, temp_max_sum);
    return temp_max_sum;
}

bool test1(){

/********** Binary Node Tree ***********/
    BinaryTreeNode *root = new BinaryTreeNode(7);
    root->left = new BinaryTreeNode(10);
    root->left->left = new BinaryTreeNode(-3);
    root->left->right = new BinaryTreeNode(-17);
    root->left->right->right = new BinaryTreeNode(17);

    root->right = new BinaryTreeNode(10);
    root->right->right = new BinaryTreeNode(5);
    root->right->right->left = new BinaryTreeNode(2);
    root->right->right->left->right= new BinaryTreeNode(-6);
    root->right->right->right = new BinaryTreeNode(-5);
    root->right->right->right->right = new BinaryTreeNode(7);


/******** STEP 1 *********/
    cout << "test1()" << endl;
    cout << "STEP 1" << endl;

/**** Root node & desired_sum = 17 ***/
    cout << "Root node & desired_sum = 17" << endl;

    string BUFFER = "";
    int DESIRED_SUM = 17;
    find_and_print_sum_of_nodes(root, DESIRED_SUM, 0, BUFFER);
//    Expected paths:
//        7 10
//        7 10
//        7 10 -17 17
//        17
//        7 10 5 -5
//        10 5 2
//        10 5 -5 7

    cout << endl;

/**** Node 5 & desired_sum = 7 ****/
    cout << "Node 5 & desired_sum = 7" << endl;
    DESIRED_SUM = 7;
    BinaryTreeNode *val5 = root->right->right;
    find_and_print_sum_of_nodes(val5, DESIRED_SUM, 0, BUFFER);
//    Expected paths:
//        5 2
//        5 -5 7
//        7

/**** Root node & desired_sum = 0 ****/
    cout << "Root node & desired_sum = 0" << endl;
    DESIRED_SUM = 0;
    find_and_print_sum_of_nodes(root, DESIRED_SUM, 0, BUFFER);
//    Expected paths:
//        7 10 -17
//        -17 17
//        -5 5

/********* STEP 2 *********/
    int max_sum = find_max_sum_of_nodes(root);
    ASSERT_TRUE(max_sum = 34);

    return true;
}

bool test2(){
    BinaryTreeNode *root_tree_2 = new BinaryTreeNode(-7);
    string BUFFER = "";

    cout << endl << "----------Test 2----------" << endl;

    root_tree_2->left = new BinaryTreeNode(3);
    root_tree_2->right = new BinaryTreeNode(1);
    root_tree_2->left->left = new BinaryTreeNode(16);
    root_tree_2->left->right = new BinaryTreeNode(-10);
    root_tree_2->left->right->right = new BinaryTreeNode(5);
    root_tree_2->right->left = new BinaryTreeNode(4);
    root_tree_2->right->right = new BinaryTreeNode(-6);
    root_tree_2->right->right->left = new BinaryTreeNode(-8);

    cout << "Root node & desired_sum = 16" << endl;
    find_and_print_sum_of_nodes(root_tree_2, 16, 0, BUFFER);
    cout << "Root node & desired_sum = 4" << endl;
    find_and_print_sum_of_nodes(root_tree_2, 4, 0, BUFFER);
    cout << "Root node & desired_sum = -2" << endl;
    find_and_print_sum_of_nodes(root_tree_2, -2, 0, BUFFER);
    cout << "Root node & desired_sum = -11" << endl;
    find_and_print_sum_of_nodes(root_tree_2, -11, 0, BUFFER);
    cout << "Root node & desired_sum = 5" << endl;
    find_and_print_sum_of_nodes(root_tree_2, 5, 0, BUFFER);

    int max_sum = find_max_sum_of_nodes(root_tree_2);
    ASSERT_TRUE(max_sum == 19);
    ASSERT_TRUE(find_max_sum_of_nodes(root_tree_2->right) == 5);
    ASSERT_TRUE(find_max_sum_of_nodes(root_tree_2->left->left) == 16);

    return true;
}

bool test3(){
    BinaryTreeNode *root_tree_3 = new BinaryTreeNode(1);
    string BUFFER = "";

    cout << endl << "----------Test 3----------" << endl;

    root_tree_3->left = new BinaryTreeNode(2);
    root_tree_3->right = new BinaryTreeNode(3);
    root_tree_3->left->left = new BinaryTreeNode(4);
    root_tree_3->left->right = new BinaryTreeNode(5);
    root_tree_3->right->left = new BinaryTreeNode(6);
    root_tree_3->right->right = new BinaryTreeNode(7);
    root_tree_3->left->left->left = new BinaryTreeNode(8);
    root_tree_3->left->left->right = new BinaryTreeNode(9);
    root_tree_3->left->right->left = new BinaryTreeNode(10);
    root_tree_3->left->right->right = new BinaryTreeNode(11);


    cout << "Root node & desired_sum = 7" << endl;
    find_and_print_sum_of_nodes(root_tree_3, 7, 0, BUFFER);
    cout << "Root node & desired_sum = 8" << endl;
    find_and_print_sum_of_nodes(root_tree_3, 8, 0, BUFFER);
    cout << "Root node & desired_sum = 1" << endl;
    find_and_print_sum_of_nodes(root_tree_3, 1, 0, BUFFER);
    cout << "Root node & desired_sum = 10" << endl;
    find_and_print_sum_of_nodes(root_tree_3, 10, 0, BUFFER);
    cout << "Root node & desired_sum = 11" << endl;
    find_and_print_sum_of_nodes(root_tree_3, 11, 0, BUFFER);
    cout << "Root node & desired_sum = 16" << endl;
    find_and_print_sum_of_nodes(root_tree_3, 16, 0, BUFFER);
    cout << "Node 2 & desired_sum = 15" << endl;
    find_and_print_sum_of_nodes(root_tree_3->left, 15, 0, BUFFER);

    int max_sum = find_max_sum_of_nodes(root_tree_3);
    ASSERT_TRUE(max_sum == 31);
    ASSERT_TRUE(find_max_sum_of_nodes(root_tree_3->left) == 31)
    ASSERT_TRUE(find_max_sum_of_nodes(root_tree_3->right) == 16)
    ASSERT_TRUE(find_max_sum_of_nodes(root_tree_3->left->right) == 26)
    cout << endl;
    return true;
}

int main() {

    ASSERT_TRUE(test1());
    ASSERT_TRUE(test2());
    ASSERT_TRUE(test3());

    cout << "All tests PASS!!!" << endl;
}