#include <iostream>
#include <string>
#include "practice_excercise_2.cpp"

using namespace std;

// PURPOSE: Returns the test result
string get_status_str(bool status) {
    return status ? "TEST PASSED" : "TEST FAILED";
}

int main() {
    //struct BinaryTreeNode root = BinaryTreeNode(5);
}
