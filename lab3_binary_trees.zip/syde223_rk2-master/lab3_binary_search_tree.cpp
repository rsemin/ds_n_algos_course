/*
 * Kha Nguyen - 20782252
 * Roman Semin -
 */
#include <iostream>
#include <stack>
#include "lab3_binary_search_tree.hpp"

using namespace std;

// PURPOSE: Default/empty constructor
BinarySearchTree::BinarySearchTree() {
    root = NULL;
    size = 0;
}

// PURPOSE: Explicit destructor of the class BinarySearchTree
BinarySearchTree::~BinarySearchTree() {
}

// PURPOSE: Returns the number of nodes in the tree
unsigned int BinarySearchTree::get_size() const {
	return size;
}

// PURPOSE: Returns the maximum value of a node in the tree
// if the tree is empty, it returns (-1, "N/A")
BinarySearchTree::TaskItem BinarySearchTree::max() const { // DONE
    if(size == 0){
        return BinarySearchTree::TaskItem(-1, "N/A");
    }
    else{
        /*
         * The max value of a node will be on the very right of the tree
         * If you treat the tree as if it was a singly linked list, you would
         * probably have to travel to the very right node until you hit a NULL
         * something similar to like if(cur->right == NULL), return priority or
         * something like that
         */
        TaskItem* cur = root;
        while(cur->right){
            cur = cur->right;
        }
        return *cur;  // TODO: check the return value
    }
}

// PURPOSE: Returns the minimum value of a node in the tree
// if the tree is empty, it returns (-1, "N/A")
BinarySearchTree::TaskItem BinarySearchTree::min() const { // DONE
    if(size == 0){
        return BinarySearchTree::TaskItem(-1, "N/A");
    }
    /*
     * Similarly, the minimum value of the tree would be on the very left.
     * same implementation as above, only with left instead of right
     */
    TaskItem* cur = root;
    while(cur->left){
        cur = cur->left;
    }
    return *cur;
}

// PURPOSE: Returns the tree height
unsigned int BinarySearchTree::height() const {
	return (get_node_depth(root) - 1);
}

// PURPOSE: Prints the contents of the tree; format not specified
void BinarySearchTree::print() const { // DONE
    /*
     * Take either the Breadth First Traversal using a queue or the Depth
     * First Traversal using a stack in order to move around to each pointer
     * to print its contents
     */
    // InOrder Traversal
    stack<TaskItem*> s;
    TaskItem* cur = root;
    while(cur || !s.empty()){
        if(cur){
            s.push(cur);
            cur = cur->left;
        }else{
            cur = s.top(); s.pop();
            cout << cur->priority << " Description: " << cur->description << endl;
            cur = cur->right;
        }
    }
}

// PURPOSE: Returns true if a node with the value val exists in the tree	
// otherwise, returns false
bool BinarySearchTree::exists( BinarySearchTree::TaskItem val ) const {

    TaskItem* cur = root;
    while (cur){
        if (val.priority == cur->priority){
            return true;
        }else if (val.priority > cur->priority){ //TODO: val. ???
            cur = cur->right;
        }else if (val.priority < cur->priority){
            cur = cur->left;
        }
    }
	return false; // in case we did not find the value in the loop
}

// PURPOSE: Optional helper function that returns a pointer to the root node
BinarySearchTree::TaskItem* BinarySearchTree::get_root_node() { //TODO: definitely needs a change this and below returns 2 different hex values
    return root;
}

// PURPOSE: Optional helper function that returns the root node pointer address
BinarySearchTree::TaskItem** BinarySearchTree::get_root_node_address() {
    return &root; //TODO: check if this is right, this and above returns 2 different hex values
}

//Roman's helper function
// PURPOSE: get root of the node that we need
BinarySearchTree::TaskItem* BinarySearchTree::get_root_of_any_node(TaskItem* n) { //TODO: definitely needs a change
    bool found = false;
    TaskItem* cur = root;

    while (!found){
        if ((cur->left && cur->left == n) || (cur->right && cur->right == n)){
            found = true;
            return cur;
        }
        if(n->priority < cur->priority){
            cur = cur->left;
        }else if (n->priority > cur->priority){
            cur = cur->right;
        }
    }
}

//Roman's helper function
// PURPOSE: find the node that we need based on the value passed in
BinarySearchTree::TaskItem* BinarySearchTree::find_node(TaskItem val) { //TODO: definitely needs a change
    bool found = false;
    TaskItem* cur = root;

    while (!found){
        if (cur->priority == val.priority){
            found = true;
            return cur;
        }
        if(val.priority < cur->priority){
            cur = cur->left;
        }else if (val.priority > cur->priority){
            cur = cur->right;
        }
    }
}

// PURPOSE: Optional helper function that gets the maximum depth for a given node
int BinarySearchTree::get_node_depth( BinarySearchTree::TaskItem* n ) const { // Found this code online
    //Recursive Solution
    if (n == NULL)
        return 0;
    else
    {
        int left_d = get_node_depth(n->left);
        int right_d = get_node_depth(n->right);
        if (left_d > right_d)
            return(left_d + 1);
        else return(right_d + 1);
    }
    return 0;
}

// PURPOSE: Inserts the value val into the tree if it is unique
// returns true if successful; returns false if val already exists
bool BinarySearchTree::insert( BinarySearchTree::TaskItem val ) {
    if(exists(val)) return false; // kinda works
    if(root == NULL){

        TaskItem* new_item = new TaskItem(val.priority, val.description); //TODO: deallocate new_item
        root = new_item;

    }else{
        TaskItem* cur = root;
        while(cur){
            if(cur->priority < val.priority){
                if(cur->right){
                    cur = cur->right;
                }else{
                    cur->right = &val;
                    cur = NULL;
                }
            }else if (cur->priority > val.priority){
                if(cur->left){
                    cur = cur->left;
                }else{
                    cur->left = &val;
                    cur = NULL;
                }
            }
        }
    }
    size++;
    return true;
}

// PURPOSE: Removes the node with the value val from the tree
// returns true if successful; returns false otherwise
bool BinarySearchTree::remove( BinarySearchTree::TaskItem val ) {
    if (root == NULL || !exists(val)) return false;
    //TaskItem* to_remove = new TaskItem(val.priority, val.description); //TODO: deallocate to_remove
    TaskItem* to_remove = find_node(val);
    TaskItem* init_root = NULL;
    TaskItem* successor_root = NULL;
    bool delete_complete = false;
    while (!delete_complete){
        // CASE 1: val is a leaf node
        //Purpose: the only case where the node gets deleted
        if (!to_remove->right && !to_remove->left){
            if (to_remove == root){
                root = NULL;
            }else{
                if (!init_root) init_root = get_root_of_any_node(to_remove);
                init_root->left == to_remove ? init_root->left = NULL : init_root->right = NULL;
            }
            to_remove = NULL; // deletion
            delete_complete = true;
        }
            // CASE 2: val has one child
            //Purpose: swap the to_remove node with the only child
        else if ((to_remove->left && !to_remove->right) || (to_remove->right && !to_remove->left)){
            // Left child
            if (to_remove->left){ //TODO: check this condition
                if (!init_root) to_remove == root ? init_root = NULL : init_root = get_root_of_any_node(to_remove);
                //to_remove
                TaskItem* left_node = to_remove->left;
                TaskItem* right_node = to_remove->right;
                //Reassign to_remove pointers
                to_remove->right = left_node->right;
                to_remove->left = left_node->left;
                //Reassign right_node pointers
                left_node->right = right_node;
                left_node->left = to_remove;
                //Reassign to_remove parent pointer
                if(init_root) {
                    if(init_root->left == to_remove){
                        init_root->left = left_node;
                        init_root = init_root->left;
                    }else{
                        init_root->right = left_node;
                        init_root = init_root->right;
                    }
                }else{
                    root = left_node;
                }
            }else if (to_remove->right){
                if (!init_root) to_remove == root ? init_root = NULL : init_root = get_root_of_any_node(to_remove);
                //to_remove
                TaskItem* left_node = to_remove->left;
                TaskItem* right_node = to_remove->right;
                //Reassign to_remove pointers
                to_remove->right = right_node->right;
                to_remove->left = right_node->left;
                //Reassign right_node pointers
                right_node->right = to_remove;
                right_node->left = left_node;
                //Reassign to_remove parent pointer
                if(init_root) {
                    if(init_root->left == to_remove){
                        init_root->left = right_node;
                        init_root = init_root->left;
                    }else{
                        init_root->right = right_node;
                        init_root = init_root->right;
                    }
                }else{
                    root = right_node;
                }
            }
        }
            // CASE 3: val has two children
            //Purpose: swap to_remove with successor
        else if (to_remove->right && to_remove->left){
            TaskItem* cur = to_remove->right;
            while(cur->left){
//                if (!cur->left->left){
//                    //setting the root
//                    init_root = cur;
//                }
                cur = cur->left;
            }
            if (!init_root) to_remove == root ? init_root = NULL : init_root = get_root_of_any_node(to_remove); // get parent for to_remove
            if (!successor_root) successor_root = get_root_of_any_node(cur); //get parent node of successor
            // to_remove
            // cur (successor)
            TaskItem* left_node = to_remove->left;
            TaskItem* right_node = to_remove->right;
            // Reassign to_remove pointers
            to_remove->right = cur->right;
            to_remove->left = cur->left;
            // Reassign cur (successor) pointers
            right_node == cur ? cur->right = to_remove : cur->right = right_node;
            left_node == cur ? cur->left = to_remove : cur->left = left_node;
            //Reassign the root node of to_remove
            if (successor_root != to_remove) (successor_root->left == cur ? successor_root->left = to_remove : successor_root->right = to_remove);
            //Reassign to_remove parent pointer
            if(init_root) {
                init_root->left == to_remove ? init_root->left = cur : init_root->right = cur;
                init_root = successor_root;
            }else{
                root = cur;
            }
            if (successor_root == to_remove) {
                init_root = cur;
            }else{
                init_root = successor_root;
            }
            successor_root = NULL;
        }
    }
    size--;
    return true;
}
