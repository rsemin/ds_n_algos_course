/*
 * Kha Nguyen - 20782252
 * Roman Semin -
 */
#include "lab3_priority_queue.hpp"
#include <iostream>

using namespace std;

// PURPOSE: Parametric constructor 
// initializes heap to an array of (n_capacity + 1) elements
PriorityQueue::PriorityQueue(unsigned int n_capacity) { // Check over
    heap = new TaskItem* [n_capacity + 1]; // Determine whether or not to keep it static
    capacity = n_capacity;
    size = 0;
}

// PURPOSE: Explicit destructor of the class PriorityQueue
PriorityQueue::~PriorityQueue() { // Not done yet
}

// PURPOSE: Returns the number of elements in the priority queue
unsigned int PriorityQueue::get_size() const {
	return size; // Double check cause this feels off
}

// PURPOSE: Returns true if the priority queue is empty; false, otherwise
bool PriorityQueue::empty() const {
    if (size == 0){  // Double check
        return true;
    }
    else{
        return false;
    }
}

// PURPOSE: Returns true if the priority queue is full; false, otherwise
bool PriorityQueue::full() const {  // double check
    if(size == capacity){
        return true;
    }
    else{
        return false;
    }

}

// PURPOSE: Prints the contents of the priority queue; format not specified
void PriorityQueue::print() const {
    for(int i = 1; i <= size; i++){
        cout << "Task Item " << i << endl;
        cout << "Priority: " << heap[i]->priority << endl;
        cout << "Description: " << heap[i]->description << endl << endl;
    }
}

// PURPOSE: Returns the max element of the priority queue without removing it
// if the priority queue is empty, it returns (-1, "N/A")
PriorityQueue::TaskItem PriorityQueue::max() const { // Double check
    if(size == 0){
        return TaskItem(-1, "NULL");
    }
    else{
        return *heap[1];
    }
}

// PURPOSE: Inserts the given value into the priority queue
// re-arranges the elements back into a heap
// returns true if successful and false otherwise
// priority queue does not change in capacity
bool PriorityQueue::enqueue( TaskItem val ) {
    // Case 1: If the priority queue is empty
    if(empty()){
        heap[1] = new TaskItem(val);
    }

    // Case 2: If the priority queue is full
    else if(full()){
        return false;
    }

    // Inserts give value into priority queue - Copied from lecture 9 slide 13
    heap[size+1] = new TaskItem(val);
    int i = size + 1;
    while(i > 1 && heap[i/2]->priority < heap[i]->priority){
        TaskItem* temp = heap[i];
        heap[i] = heap[i/2];
        heap[i/2] = temp;
        i = i/2;
    }


    // Rearranges elements back into a heap
    bool isRearranged = true;
    //Checking if children priority is less than parent priority
    i = 1;
    while(i < size/2 && (2*i < size)){
        isRearranged = isRearranged && (heap[2*i]->priority <= heap[i]->priority);
        isRearranged = isRearranged && (heap[2*i + 1]->priority <= heap[i]->priority);
        i++;
    }
    //Do this check at the end? Checks if all nodes are less than the highest priority at 1
    for(int i = 2; i < size; i++){
        isRearranged = isRearranged && (heap[1]->priority >= heap[i]->priority);
    }

    // Priority queue does not change in capacity
    bool no_capacity_change = true;
    no_capacity_change = no_capacity_change && (capacity == this->capacity);
    size++;

    if(isRearranged && no_capacity_change){
        return true;
    }
    else{
        return false;
    }

}

// PURPOSE: Removes the top element with the maximum priority
// re-arranges the remaining elements back into a heap
// returns true if successful and false otherwise
// priority queue does not change in capacity
bool PriorityQueue::dequeue() {
    // Case 1: If the priority queue is empty
    if(empty()){
        return false;
    }

    //Moves the queue down after dequeueing
    for(int i = 1; i < size - 1; i++){
        heap[i] = heap[i+1];
    }
    size--;
    // Re-arranges the remaining elements back into a heap
    if(!empty()){

        int i = 1;
        while((i*2 + 1 <=size) && ((heap[2*i]->priority > heap[i]->priority) || (heap[2*i + 1]->priority > heap[i]->priority))){
            if(heap[2*i]->priority > heap[i]->priority){
                TaskItem* temp = heap[i];
                heap[i] = heap[2*i];
                heap[2*i] = temp;
                i++;
            }
            else if(heap[2*i + 1]->priority > heap[i]->priority){
                TaskItem* temp = heap[i];
                heap[i] = heap[2*i + 1];
                heap[2*i + 1] = temp;
                i++;
            }
        }
    }


    // Priority queue does not change in capacity
    bool isRearranged = true;
    //Checking if children priority is less than parent priority
    int i = 1;
    while(i < size/2 && (2*i < size)){
        isRearranged = isRearranged && (heap[2*i]->priority <= heap[i]->priority);
        isRearranged = isRearranged && (heap[2*i + 1]->priority <= heap[i]->priority);
        i++;
    }
    //Do this check at the end? Checks if all nodes are less than the highest priority at 1
    for(int i = 2; i < size; i++){
        isRearranged = isRearranged && (heap[1]->priority >= heap[i]->priority);
    }

    // Priority queue does not change in capacity
    bool no_capacity_change = true;
    no_capacity_change = no_capacity_change && (capacity == this->capacity);

    if(isRearranged && no_capacity_change){
        return true;
    }
    else{
        return false;
    }
}
