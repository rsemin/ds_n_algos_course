/*
SYDE 223 - Group 49
Kha Nguyen 
Roman Semin 
*/

#include <iostream>
#include <vector>
#include <cstdlib>
#include <ctime>
#include <cassert>
using namespace std;

class Music{
    unsigned int year;
    string artist_name, music_ID;

public:
    Music(){
        year = 0;
    }

    Music(string new_artist_name, unsigned int new_year, string new_music_ID) :
		artist_name(new_artist_name), year(new_year), music_ID(new_music_ID) {}

    string get_artist(){
        return artist_name;
    }

    bool operator==(const Music& target) const{
        bool music_is_same = true;
        music_is_same = music_is_same && (artist_name == target.artist_name);
        music_is_same = music_is_same && (year == target.year);
        music_is_same = music_is_same && (music_ID == target.music_ID);
        return music_is_same;
    }

};

class Song : public Music{
 	string genre, song_name;
 	unsigned int song_length;

 public:
 	Song (){
 		song_length = 0;
	 }

	Song(string new_genre, string new_song_name, unsigned int new_song_length, Music new_music) :
		genre(new_genre), song_name(new_song_name), song_length(new_song_length), Music(new_music) {}

	bool operator==(const Song& target) const {
		bool are_equal = true;
		are_equal = are_equal && (genre == target.genre);
		are_equal = are_equal && (song_name == target.song_name);
		are_equal = are_equal && (song_length == target.song_length);
        are_equal = are_equal && (static_cast<Music>(*this) == static_cast<Music>(target));
        return are_equal;
	}

    string get_song_name(){
        return song_name;
    }
 };

class Playlist{
     vector<Song> my_playlist;

public:
    bool insert_song(Song& song_info){
        bool status = true;
        int counter = 0;

        for (int i = 0; i < my_playlist.size(); i++){
            if (song_info.get_artist() == my_playlist.at(i).get_artist()){
                counter++;
            }
            //Verifies if it's the same song
            status = status && !(song_info == my_playlist.at(i));
        }
        if (counter > 2){
            status = false;
        }

        if (status) {
            my_playlist.push_back(song_info);
        }
        return status;
    }

    Playlist shuffle_songs(){
        Playlist new_playlist;
        Playlist copied;
        vector<int> shuffle;

        //Generate a unique random vector array
        for(int i = 0; i < my_playlist.size(); i++){
            bool original_number = true;
            int random_number = rand() % my_playlist.size();
            for (int j = 0; j < shuffle.size(); j++){
                if(random_number == shuffle.at(j)){
                    original_number = false;
                    i--;
                }
            }
            if(original_number){
                shuffle.push_back(random_number);
            }
        }

        //Swap Values
        /*
        Copy playlist into another level
        Shuffle vector will list the spot where the song in that position will switch to 
        the current position going through the vector
        */
        for(int i = 0; i < shuffle.size(); i++){
            copied.my_playlist.push_back(my_playlist.at(i));
        }
        for(int i = 0; i < shuffle.size(); i++){
            new_playlist.my_playlist.push_back(copied.my_playlist.at(shuffle.at(i)));
        }

        return new_playlist;
    }

    string playlist_get_artist(int i){
        return my_playlist.at(i).get_artist();
    }

    string playlist_get_song_name(int i){
        return my_playlist.at(i).get_song_name();
    }

    int get_playlist_size(){
        return my_playlist.size();
    }

    friend Playlist operator+(const Playlist& playlist1, const Playlist& playlist2);
 };

Playlist operator+(const Playlist& playlist1, const Playlist& playlist2){
	Playlist new_playlist;
	for (int i = 0; i < playlist1.my_playlist.size(); i++){
		new_playlist.my_playlist.push_back(playlist1.my_playlist.at(i));
	}
	for (int i = 0; i < playlist2.my_playlist.size(); i++){
		new_playlist.my_playlist.push_back(playlist2.my_playlist.at(i));
	}

	return new_playlist;
}

bool test_insert_song(){

	/****** ATTRIBUTES DECLARATION ******/
	bool testing_passed = false;
	bool try_duplicating;
	bool try_four_songs;

	//Music instances
	//Music(string new_artist_name, unsigned int new_year, string new_music_ID)
	Music billie_eilish_2019("Billie Eilish", 2019, "test_id");
	Music billie_eilish_2018("Billie Eilish", 2018, "test_id_1");
    Music illenium_2019("Illenium", 2019, "illenium_id");

	//Song instances
	//Song(string new_genre, string new_song_name, unsigned int new_song_length, Music new_music)
	Song bad_guy("Pop", "Bad Guy", 123, billie_eilish_2019);

	Song ocean_eyes("Pop", "Ocean Eyes", 205, billie_eilish_2018);
	Song bury_a_friend("Pop", "Bury a Friend", 172, billie_eilish_2019);
	Song wish_you_were_gay("Pop", "Wish You Were Gay", 198, billie_eilish_2019);
    Song take_you_down("EDM", "Take You Down", 240, illenium_2019);

	//Playlist instances
	Playlist test_playlist_1;
	Playlist test_playlist_2;

	/****** FUNCTIONALITY ******/

	//Inserting a duplicate song into playlist

	try_duplicating = test_playlist_1.insert_song(bad_guy);
    try_duplicating = test_playlist_1.insert_song(bad_guy); //false condition (makes the try_duplicating false) => testing_passed = true
    assert(try_duplicating == false);
    cout << "Inserting duplicate song test passed" << endl;

	//Inserting	four songs with the same artist into the playlist
	try_four_songs = test_playlist_2.insert_song(bad_guy);
	try_four_songs = test_playlist_2.insert_song(ocean_eyes);
	try_four_songs = test_playlist_2.insert_song(bury_a_friend);
	try_four_songs = test_playlist_2.insert_song(wish_you_were_gay); //false condition (makes the try_four_songs false) => testing_passed = true
    assert(try_four_songs == false);
    cout << "Inserting 4 songs with the same artist name into playlist passed" << endl;

    testing_passed = true;

	/****** RETURN THE RESULT ******/
	return testing_passed;
}

bool test_shuffle_songs(){

    /****** ATTRIBUTES DECLARATION ******/
    bool testing_passed = false;
    bool random_songs;

    Playlist test_playlist_shuffle;
    Playlist shuffled_playlist;
    //Music instances
	//Music(string new_artist_name, unsigned int new_year, string new_music_ID)
	Music billie_eilish_2019("Billie Eilish", 2019, "test_id");
	Music billie_eilish_2018("Billie Eilish", 2018, "test_id_1");
    Music illenium_2019("Illenium", 2019, "illenium_id");
    Music martin_garrix("Martin Garrix", 2019, "mg_id");
    Music said_the_sky("Said The Sky", 2019, "sts_id");
    Music seven_lions("Seven Lions", 2019, "7l_id");

	//Song instances
	//Song(string new_genre, string new_song_name, unsigned int new_song_length, Music new_music)
	Song bad_guy("Pop", "Bad Guy", 123, billie_eilish_2019);

	Song ocean_eyes("Pop", "Ocean Eyes", 205, billie_eilish_2018);
	Song bury_a_friend("Pop", "Bury a Friend", 172, billie_eilish_2019);
	Song wish_you_were_gay("Pop", "Wish You Were Gay", 198, billie_eilish_2019);

    Song take_you_down("EDM", "Take You Down", 240, illenium_2019);
    Song burn_out("EDM", "Burn Out", 226, martin_garrix);
    Song horizon("EDM", "Horizon", 215, seven_lions);
    Song hero("EDM", "Hero", 237, said_the_sky);
    Song hold_on("EDM", "Hold On", 200, illenium_2019);

    random_songs = test_playlist_shuffle.insert_song(bad_guy);
    random_songs = test_playlist_shuffle.insert_song(ocean_eyes);
    random_songs = test_playlist_shuffle.insert_song(bury_a_friend);
    random_songs = test_playlist_shuffle.insert_song(burn_out);
    random_songs = test_playlist_shuffle.insert_song(hero);
    random_songs = test_playlist_shuffle.insert_song(horizon);
    random_songs = test_playlist_shuffle.insert_song(take_you_down);

    //TEST: Shuffle Playlist
    shuffled_playlist = test_playlist_shuffle.shuffle_songs();

    //Verification that playlist is shuffled
    /*
    If more than half the songs in the original playlist are in the same position as the new playlist,
    then the program will shuffle it again to guarantee a shuffle
    */
    int counter = 0;
    for(int i = 0; i < shuffled_playlist.get_playlist_size(); i++){
        if (shuffled_playlist.playlist_get_song_name(i) == test_playlist_shuffle.playlist_get_song_name(i)){
            counter++;
        }
    }
    while(counter > (shuffled_playlist.get_playlist_size() / 2)){
        shuffled_playlist = test_playlist_shuffle.shuffle_songs();
    }
    assert(counter < (shuffled_playlist.get_playlist_size() / 2) == true);
    cout << "Shuffling passes" << endl;

    //TEST - Adding song to shuffled Playlist
    int old_playlist_size = shuffled_playlist.get_playlist_size();
    random_songs = shuffled_playlist.insert_song(hold_on);
    assert(random_songs == true);
    old_playlist_size++;
    assert(shuffled_playlist.get_playlist_size() == (old_playlist_size));
    assert(shuffled_playlist.playlist_get_song_name(shuffled_playlist.get_playlist_size() - 1) == hold_on.get_song_name());
    cout << "Adding song to shuffled Playlist passed" << endl;


    testing_passed = true;
    return testing_passed;
}

int main(){
    srand(time(0));
    assert(test_insert_song() == true);
    assert(test_shuffle_songs() == true);
    cout << "All Tests Passed" << endl;
    return 0;
}
